const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const express = require('express');
const router = express.Router();
const {Genres, validate} = require('../models/genre.js');
//get all genres
router.get('/', async (req, res)=> {
    const genres = await Genres.find().sort({name: 1});
    res.send(genres);
});

//create genre
router.post('/', auth, async (req, res)=> {
  const {error} = validate(req.body);
  if(error) return res.status(404).send(error.details[0].message);
  const genre = new Genres({
      name: req.body.name
  });
  const currentGenre = await genre.save();
  res.send(currentGenre);
});

//update genre
router.put('/:id', async (req, res)=> {
    const { errror } = validate(req.body.name);
    if(error) return res.status(404).send(error.details[0].message);
    const genre = await Genres.findByIdAndUpdate(req.params.id, {$set: {"name": req.body.name}}, {new: false, useFindAndModify: false});
    if(!genre) return res.status(404).send('id that you that passed is not valid');
    res.send(genre);
});

//find genre through id
router.get('/:id', async (req, res)=> {
    const genre = await Genres.findById(req.params.id);
    if(!genre) return res.status(404).send('id that you that passed is not valid');
    res.send(genre);
});

//delete genre 
router.delete('/:id', [auth, admin], async (req,res)=> {
    const genre = await Genres.findByIdAndDelete(req.params.id);
    if(!genre) return res.status(404).send('id that you that passed is not valid');
    res.send(genre);
})


module.exports = router;