const auth = require('../middleware/auth');
const express = require('express');
const router = express.Router();
const {Movie, validate} = require('../models/movie');
const {Genres} = require('../models/genre');
//get all movies
router.get('/', async (req, res)=>{
    const movies = await Movie.find().sort({"name" : -1});
    res.send(movies);
});
// create movie
router.post('/', auth, async (req, res)=> {
    try{
        const { error } = validate(req.body);
        if(error) return res.status(404).send(error.details[0].message);

        const genre =  await Genres.findById(req.body.genreId); 
        if(!genre) return res.status(404).send('invalid genre Id');

        let movie = new Movie({
            title: req.body.title,
            genre: {
                _id: genre._id,
                name: genre.name
            },
            numberInStock: req.body.numberInStock,
            dailyRentalRate: req.body.dailyRentalRate
        });
        movie = await movie.save(); 
        res.send(movie);
    }catch(err){
        res.status(404).send(err.message);
    }     
});
//update movie
router.put('/:id', async (req, res)=>{
    try{
        const { error } = validate(req.body);
        if(error) return res.status(404).send(error.details[0].message);

        const genre =  await Genres.findById(req.body.genreId); 
        if(!genre) return res.status(404).send('invalid genre Id');

        const movie = await Movie.findByIdAndUpdate(req.params.id, {$set:{
            title: req.body.title,
            genre: {
                _id: genre._id,
                name: genre.name
            },
            numberInStock: req.body.numberInStock,
            dailyRentalRate: req.body.dailyRentalRate 
        }}, {new: true});

        if(!movie) return res.status(404).send('there no movie related to this movie id');

        res.send(movie);
    }catch(err){
        res.status(404).send(err.message);
    }    
});
// remove movie
router.delete('/:id', async (req, res)=>{
    const movie = await Movie.findByIdAndDelete(req.params.id);
    if(!movie) return res.status(404).send('there no movie related to this movie id');
    res.send(movie);
});
//find movie
router.get('/:id', async (req, res)=>{
    const movie = await Movie.findById(req.params.id);
    if(!movie) return res.status(404).send('there no movie related to this movie id');
    res.send(movie);   
});

module.exports = router; 