const config = require('config');
const Joi = require('joi');
Joi.objectId = require('joi-objectid')(Joi);
const express = require('express');
const mongoose = require('mongoose');
const genres = require('./routes/genres');
const customer = require('./routes/customer');
const movies = require('./routes/movies');
const rental = require('./routes/rental');
const users = require('./routes/user');
const auth = require('./routes/auth');
const app = express();

app.use(express.json());
app.use('/api/genres', genres);
app.use('/api/customer', customer);
app.use('/api/movies', movies);
app.use('/api/rental', rental);
app.use('/api/users', users);
app.use('/api/auth', auth);

if(! config.get('jwtSecretKey')){
    console.log('FATAL ERROR: jwtSecretKey is not set');
    process.exit(1);
}
mongoose.connect('mongodb://localhost/vidly', {useNewUrlParser: true, useUnifiedTopology: true})
    .then(()=> {console.log('connected to mongodb')})
    .catch(err=> {console.log('something went wrong',err)});


const port = process.env.PORT || 3000;
app.listen(port, ()=> {console.log(`connected to port ${port}....`)});


