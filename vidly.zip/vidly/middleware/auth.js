const config = require('config');
const jwt = require('jsonwebtoken');

function auth(req, res, next){
    const token = req.header('x-auth-token');
    if(!token) res.status('401').send('access denied. No token key found!..');
    
    try{
        const decode = jwt.verify(token, config.get('jwtSecretKey'));
        req.user = decode;
        next();
    }catch(error){
        res.status(400).send('Invalid token!')
    }
}

module.exports = auth;