const Joi = require('joi');
const mongoose = require('mongoose');

const genreSchema = new mongoose.Schema({
    name: {
        type: String,
        minlength: 3,
        maxlength: 50,
        required: true
    }
});
const Genres = mongoose.model('genre', genreSchema); 

//function to validate input genre
function validateGenre(genre){
    const schema = {
        name: Joi.string().min(3).max(50).required()
    };
    return Joi.validate(genre,schema);
}


module.exports.genreSchema = genreSchema;
module.exports.Genres = Genres; 
module.exports.validate = validateGenre; 